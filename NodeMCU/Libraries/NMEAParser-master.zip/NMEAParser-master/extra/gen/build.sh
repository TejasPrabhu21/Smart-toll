#!/bin/bash

gcc -o nmeagen NMEASentencesGenerator.c
