#!/bin/bash

c++ -o testNMEA testNMEA.cpp
